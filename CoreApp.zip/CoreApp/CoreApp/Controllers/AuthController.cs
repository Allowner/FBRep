﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Facebook;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;

namespace CoreApp.Controllers
{
    [Route("auth")]
    public class AuthController : Controller
    {
        [Route("signin")]
        public IActionResult SignIn()
        {
            return Challenge(new AuthenticationProperties { RedirectUri = "/" });
        }

        [Route("check")]
        public async Task<object> CheckAsync()
        {
            string token = await AuthenticationHttpContextExtensions.GetTokenAsync(HttpContext, "access_token");
            /*FacebookClient client = new FacebookClient(token);
            string result = client.Get("me/?fields=id,name").ToString();*/
            return token;
        }
    }
}
